'use client';

import React from 'react';

import {
  normalizeUser,
  isValidUserId,
} from '@client/src/components/business-ui/utils/user';
import type { UserInput } from '@client/src/components/business-ui/types/user';
import { UserWithAvatar } from '@client/src/components/business-ui/user-display/user-with-avatar';
import { UserProfile } from '@client/src/components/business-ui/user-profile/user-profile';
import { cn } from '@/lib/utils';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@client/src/components/ui/popover';

/**
 * 阻止 Popover 打开时的自动聚焦。
 *
 * Radix 的 FocusScope 在弹层挂载时会把焦点给容器里第一个可聚焦元素。人员卡片
 * 挂载那一刻内容就已经在了（飞书名片里有「消息」等按钮），于是一打开就有个
 * 按钮带上焦点环。这是张只读预览卡，焦点应该留在触发器上 —— Radix 自己的
 * HoverCard 也是这么处理的。
 */
const handleProfileOpenAutoFocus = (event: Event) => {
  event.preventDefault();
};

export interface IUserDisplayProps {
  /**
   * 用户列表
   */
  value?: string | string[] | UserInput | UserInput[];
  size?: 'small' | 'medium' | 'large';
  className?: string;
  style?: React.CSSProperties;
  showLabel?: boolean;
  showUserProfile?: boolean;
  userId?: string;
  user_id?: string;
}

export const UserDisplay: React.FC<IUserDisplayProps> = ({
  userId,
  user_id,
  value,
  size,
  className,
  style,
  showLabel = true,
  showUserProfile = true,
}) => {
  // 统一规范化为 User[]，兼容所有格式
  const normalizedUsers = React.useMemo(() => {
    let list: UserInput[];

    if (value) {
      // 处理 value 的不同类型
      if (Array.isArray(value)) {
        // string[] 或 UserInput[]
        list = value.map((item: string | UserInput) =>
          typeof item === 'string' ? { user_id: item } : item,
        );
      } else {
        // string 或 UserInput
        list = [typeof value === 'string' ? { user_id: value } : value];
      }
    } else if (userId) {
      // userId 快捷方式：转换为对象
      list = [{ user_id: userId }];
    } else if (user_id) {
      // user_id 快捷方式：转换为对象
      list = [{ user_id }];
    } else {
      return [];
    }

    // 转换为标准 User 类型并过滤无效 ID
    return list
      .map(normalizeUser)
      .filter((user) => isValidUserId(user.user_id));
  }, [value, userId, user_id]);

  if (!normalizedUsers.length) {
    return null;
  }

  return (
    <div className={cn('flex flex-wrap gap-1', className)} style={style}>
      {normalizedUsers.map((user) => {
        if (!showUserProfile) {
          return (
            <div key={user.user_id}>
              <UserWithAvatar data={user} size={size} showLabel={showLabel} />
            </div>
          );
        }

        return (
          <Popover key={user.user_id}>
            <PopoverTrigger asChild>
              <div>
                <UserWithAvatar
                  data={user}
                  size={size}
                  showLabel={showLabel}
                  className="cursor-pointer hover:bg-[rgba(31_35_41_0.15)] active:bg-[rgba(31_35_41_0.2)]"
                />
              </div>
            </PopoverTrigger>
            <PopoverContent
              align="start"
              sideOffset={8}
              onOpenAutoFocus={handleProfileOpenAutoFocus}
              className="w-[320px] border-0 border-border/50 bg-card p-0 shadow-[0px_8px_24px_8px_rgba(31_35_41_0.04),0px_6px_12px_rgba(31_35_41_0.04),0px_4px_8px_-8px_rgba(31_35_41_0.06)]"
            >
              <UserProfile value={user} />
            </PopoverContent>
          </Popover>
        );
      })}
    </div>
  );
};
